CREATE TABLE `iNettuts` (
`user_id` VARCHAR( 50 ) NOT NULL ,
`config` TEXT NOT NULL ,
PRIMARY KEY ( `user_id` )
);